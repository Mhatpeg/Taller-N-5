package ui.Ventana1;

import ui.BancoModel;

import javax.swing.*;

public final class Ventana1 extends JFrame{
    private JPanel panel1;
    private JTextField textField1;
    private JTextField textField2;
    private JButton iniciarSesiónButton;

    private final BancoModel bancoModel;


    public Ventana1(BancoModel bancoModel){
        // super("Iniciar Sesión");

        this.setContentPane(this.panel1);
        this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        this.bancoModel = new BancoModel();

    }
}
