package ui;

import service.Banco;
import service.BancoImpl;

public class BancoSingleton {
    /**
     * private static final Banco INSTANCE = new BancoImpl();
     *
     *     private BancoSingleton(){
     *
     *     }
     *     public static Banco getInstance(){
     *         return INSTANCE;
     *     }
     */

}
