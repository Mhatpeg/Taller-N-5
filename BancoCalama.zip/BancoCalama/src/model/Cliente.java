package model;

public class Cliente {
    private String rut;
    private String nombre;
    private int monto;
    private String clave;

    public Cliente(String rut, String nombre, int monto, String clave) {
        this.rut = rut;
        this.nombre = nombre;
        this.monto = monto;
        this.clave = clave;
    }

    public String getRut() {
        return rut;
    }

    public String getNombre() {
        return nombre;
    }

    public int getMonto() {
        return monto;
    }

    public String getClave() {
        return clave;
    }
}
