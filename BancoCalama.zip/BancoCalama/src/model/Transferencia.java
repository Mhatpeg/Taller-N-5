package model;

import javax.print.DocFlavor;

public class Transferencia {
    private String rut_Propio;
    private String rut_Destinatario;
    private int monto;
    private String mensaje;
    private String apodo;

    public Transferencia(String rut_Propio, String rut_Destinatario, int monto, String mensaje,String apodo) {
        this.rut_Propio = rut_Propio;
        this.rut_Destinatario = rut_Destinatario;
        this.monto = monto;
        this.mensaje = mensaje;
        this.apodo=apodo;
    }

    public String getApodo(){
        return apodo;
    }

    public String getRut_Propio() {
        return rut_Propio;
    }

    public String getRut_Destinatario() {
        return rut_Destinatario;
    }

    public int getMonto() {
        return monto;
    }

    public String getMensaje() {
        return mensaje;
    }
}
