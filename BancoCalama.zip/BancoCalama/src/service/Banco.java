package service;

import model.Cliente;
import model.Transferencia;

import java.util.List;

public interface Banco {
    List<Cliente> getClientes();
    List<Transferencia> getTransferencias();
    int size();
    Cliente getCliente(int posicion);
    void agregarCliente(Cliente cliente);
    void agregarTransferencia(Transferencia transferencia);

    /**
     * Carga desde el backend los Contactos.
     */
    void loadClientes();

    /**
     * Guarda en el backend los Contactos.
     */
    void saveClientes();

}
